package com.example.flutter_eqo_v2

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
